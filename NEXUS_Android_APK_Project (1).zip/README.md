# NEXUS Android APK Project

This project wraps the uploaded HTML prototype in a native Android WebView.

Main HTML entry point: code.html

## Build
Open this folder in Android Studio and choose:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The generated debug APK is normally under:
app/build/outputs/apk/debug/app-debug.apk

## Important
This is a UI/prototype wrapper. Login, matchmaking, ELO persistence, real multiplayer,
and server/database functionality still need a backend.
